// aura-project/src/pages/DashboardPage.tsx
import React from 'react';
import { VoiceInput } from '../components/VoiceInput';

export const DashboardPage: React.FC = () => {
  return (
    <div className="dashboard-page min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <VoiceInput />
    </div>
  );
};
